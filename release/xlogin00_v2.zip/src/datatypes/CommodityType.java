package datatypes;

/**
 * 
 * @author tehryn
 *
 */
public enum CommodityType {
	ROOM,
	SERVICE
}
