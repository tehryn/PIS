package datatypes;

/**
 *  @brief Enumerator for all supported currencies
 */
public enum Currency {
	CZK,
	USD,
	EUR
}
