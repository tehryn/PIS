package datatypes;

/**
 *  @brief Enumerator of possible commodity state
 */
public enum CommodityState {
	AVAILABLE,
	BLOCKED
}
